/**
 * 
 */
package com.anthem.common.bi_robo_tester.jobs;

import java.util.Date;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * @author dosapati
 *
 */
public class ExampleJob extends QuartzJobBean {
	
	private static Logger _log = LoggerFactory.getLogger(ExampleJob.class);


	/* (non-Javadoc)
	 * @see org.springframework.scheduling.quartz.QuartzJobBean#executeInternal(org.quartz.JobExecutionContext)
	 */
	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
		// TODO Auto-generated method stub
		 _log.info("Hello World from ExampleJob ! - " + new Date());
	}

}
