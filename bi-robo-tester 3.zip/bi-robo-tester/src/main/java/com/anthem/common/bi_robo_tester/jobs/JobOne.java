/**
 * 
 */
package com.anthem.common.bi_robo_tester.jobs;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * @author dosapati
 *
 */
@Service("jobone")
public class JobOne {
	private static Logger _log = LoggerFactory.getLogger(JobOne.class);

	protected void runTask() {
        _log.info("Hello World from JobOne ~~~~~~~~~~ -> " + new Date());

	}

}
