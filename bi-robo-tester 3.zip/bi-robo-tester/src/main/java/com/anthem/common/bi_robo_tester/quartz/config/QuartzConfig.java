package com.anthem.common.bi_robo_tester.quartz.config;


import org.quartz.SimpleTrigger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.MethodInvokingJobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.scheduling.quartz.SimpleTriggerFactoryBean;
 
import javax.sql.DataSource;
import java.util.Properties;

@Configuration
public class QuartzConfig {
	
	@Bean
	public MethodInvokingJobDetailFactoryBean  methodInvokingJobDetailFactoryBean() {
		MethodInvokingJobDetailFactoryBean mb = new MethodInvokingJobDetailFactoryBean();
		mb.setTargetBeanName("jobone");
		mb.setTargetMethod("runTask");
		return mb;
	}
	
	@Bean
	public SimpleTriggerFactoryBean simpleTriggerFactoryBean() {
		SimpleTriggerFactoryBean st = new SimpleTriggerFactoryBean();
		st.setJobDetail(methodInvokingJobDetailFactoryBean().getObject());
		st.setStartDelay(3000);
		st.setRepeatInterval(0);
		st.setRepeatCount(0);
		return st;
	}
	
	@Bean
	public SchedulerFactoryBean schedulerFactoryBean() {
		SchedulerFactoryBean sfb = new SchedulerFactoryBean();
		sfb.setTriggers(simpleTriggerFactoryBean().getObject());
		
		return sfb;
	}

}
