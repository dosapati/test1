/**
 * 
 */
package com.anthem.common.bi_robo_tester.task;

import static org.quartz.DateBuilder.evenMinuteDate;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.TriggerKey;
import static org.quartz.impl.matchers.GroupMatcher.jobGroupEquals;
import static org.quartz.impl.matchers.GroupMatcher.triggerGroupEquals;

import org.quartz.impl.triggers.SimpleTriggerImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.scheduling.quartz.SimpleTriggerFactoryBean;
import org.springframework.stereotype.Component;

import com.anthem.common.bi_robo_tester.jobs.JobOneDynamic;

/**
 * @author dosapati
 *
 */
@Component
public class CommonLoaderTask {
	
	@Autowired
	SchedulerFactoryBean  schedulerFactoryBean;
	
	private static final Logger log = LoggerFactory.getLogger(CommonLoaderTask.class);

	  private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

	  @Scheduled(fixedRate = 10000)
	  public void reportCurrentTime() {
	    log.info("The time is now {}", dateFormat.format(new Date()));
	    
	    log.info("schedulerFactoryBean is running --->"+schedulerFactoryBean.isRunning());
	    
	    Scheduler scheduler = schedulerFactoryBean.getScheduler();
	    
	    try {
			for(String group: scheduler.getTriggerGroupNames()) {
				for(TriggerKey triggerKey: scheduler.getTriggerKeys(triggerGroupEquals(group))) {
					System.out.println("Trigger Key --->"+triggerKey);
					scheduler.unscheduleJob(triggerKey);
				}
			}
			
			for(String group1: scheduler.getJobGroupNames()) {
				for(JobKey jobKey: scheduler.getJobKeys(jobGroupEquals(group1))) {
					System.out.println("Job Key --->"+jobKey);
					scheduler.deleteJob(jobKey);
				}
			}
		} catch (SchedulerException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    
	    JobDetail jobDetails = JobBuilder.newJob(JobOneDynamic.class).withDescription("d01").withIdentity("iden01","myGroup").storeDurably().build();
	    	
	    SimpleTriggerImpl st = new SimpleTriggerImpl();
	    st.setName("T0001");
		//st.setJobDetail(jobDetails);
	    
		st.setStartTime(evenMinuteDate(new Date()));
		st.setRepeatInterval(0);
		st.setRepeatCount(0);	
		
		try {
			scheduler.scheduleJob(jobDetails,st);
		} catch (SchedulerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    			
	    
	    
	  }
}
