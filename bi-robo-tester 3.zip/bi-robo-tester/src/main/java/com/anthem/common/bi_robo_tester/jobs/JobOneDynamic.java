/**
 * 
 */
package com.anthem.common.bi_robo_tester.jobs;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 * @author dosapati
 *
 */

public class JobOneDynamic implements Job {
	private static Logger _log = LoggerFactory.getLogger(JobOneDynamic.class);

	

	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		// TODO Auto-generated method stub
		_log.info("JobOneDynamic ~~~~~~~~~~ -> " + new Date());
	}

}
