package com.knowledgent.kariba.util;

/**
 * Created by Hari.Dosapati on 12/6/2016.
 */
public interface Constants {

  public static final String COMMAND_KEY="command";
}
