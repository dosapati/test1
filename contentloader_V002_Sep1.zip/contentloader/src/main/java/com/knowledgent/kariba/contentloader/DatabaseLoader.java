package com.knowledgent.kariba.contentloader;

import org.springframework.stereotype.Controller;

/**
 * Created by Hari.Dosapati on 11/28/2016.
 */
@Controller
public class DatabaseLoader {

  public Boolean loadData(){

    return true;
  }
}
