package com.knowledgent.kariba.schedulers;

import org.springframework.context.annotation.Configuration;

/**
 * Created by Hari.Dosapati on 11/28/2016.
 */
@Configuration
public class CommonLoaderJob {




}
