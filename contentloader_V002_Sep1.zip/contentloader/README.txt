How to Run:

1) Place the loader props file at loading location specified in application.properties
2) Build and Run the code using -> mvn package && java -jar target/contentloader-0.0.1-SNAPSHOT.jar