/**
 * 
 */
package com.anthem.testing.executor;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
/**
 * @author dosapati
 *
 */
public class PerfTestingScheduledThreadPoolExecutor {

	/**
	 * @param args
	 * @throws ExecutionException 
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		// TODO Auto-generated method stub
		Runnable runnabledelayedTask = new Runnable()
		{
			@Override
			public void run()
			{
			     System.out.println(Thread.currentThread().getName()+" is Running Delayed Task");
			}
		};
		
		Callable<String> callabledelayedTask = () -> {
		    try {
		        TimeUnit.SECONDS.sleep(1);
		        return "GoodBye! See you at another invocation...";
		    }
		    catch (InterruptedException e) {
		        throw new IllegalStateException("task interrupted", e);
		    }
		};
		
		ScheduledExecutorService scheduledPool = Executors.newScheduledThreadPool(4);
		
		//scheduledPool.

		scheduledPool.scheduleWithFixedDelay(runnabledelayedTask, 1, 1, TimeUnit.SECONDS);

		ScheduledFuture<String> sf = scheduledPool.schedule(callabledelayedTask, 4, TimeUnit.SECONDS);

		String value = sf.get();

		System.out.println("Callable returned"+value);

        scheduledPool.shutdown();

		System.out.println("Is ScheduledThreadPool shutting down? "+scheduledPool.isShutdown());
	}
	

}
